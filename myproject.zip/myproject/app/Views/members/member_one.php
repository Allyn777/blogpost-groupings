<?= view('templates/header', ['title' => $title]) ?>
<?= view('templates/navbar', ['activePage' => $activePage]) ?>
<?= view('members/_portfolio', ['member' => $member]) ?>
<?= view('templates/footer') ?>
