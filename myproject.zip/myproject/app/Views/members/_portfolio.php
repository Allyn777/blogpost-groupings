<main id="main-content">
    <section class="profile-hero">
        <div class="container profile-hero-grid">
            <div class="profile-portrait">
                <span class="profile-number"><?= esc($member['number']) ?> / 03</span>
                <img src="<?= base_url($member['image']) ?>" alt="Portrait illustration of <?= esc($member['name']) ?>">
            </div>
            <div class="profile-intro">
                <p class="eyebrow">Team member <?= esc($member['number']) ?></p>
                <h1><?= esc($member['name']) ?></h1>
                <p class="profile-role"><?= esc($member['role']) ?></p>
                <p class="profile-lead"><?= esc($member['introduction']) ?></p>
                <a class="button button-primary" href="mailto:<?= esc($member['email']) ?>">Get in touch <span aria-hidden="true">&rarr;</span></a>
            </div>
        </div>
    </section>

    <section class="profile-details">
        <div class="container details-grid">
            <div class="detail-sidebar">
                <p class="eyebrow">Personal statement</p>
                <h2>Learning today.<br>Creating tomorrow.</h2>
            </div>
            <div class="detail-content">
                <article class="detail-block education-block">
                    <span class="detail-index">01</span>
                    <div>
                        <p class="eyebrow">Education</p>
                        <h3><?= esc($member['education']['program']) ?></h3>
                        <p><?= esc($member['education']['school']) ?></p>
                        <span class="soft-label"><?= esc($member['education']['year']) ?></span>
                    </div>
                </article>

                <article class="detail-block">
                    <span class="detail-index">02</span>
                    <div>
                        <p class="eyebrow">Skills ledger</p>
                        <h3>Tools I am building</h3>
                        <div class="tag-list">
                            <?php foreach ($member['skills'] as $skill): ?>
                                <span><?= esc($skill) ?></span>
                            <?php endforeach ?>
                        </div>
                    </div>
                </article>

                <article class="detail-block">
                    <span class="detail-index">03</span>
                    <div>
                        <p class="eyebrow">Beyond the screen</p>
                        <h3>Hobbies &amp; interests</h3>
                        <ul class="interest-list">
                            <?php foreach ($member['hobbies'] as $hobby): ?>
                                <li><?= esc($hobby) ?></li>
                            <?php endforeach ?>
                        </ul>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <section class="projects-section">
        <div class="container">
            <div class="section-heading">
                <div>
                    <p class="eyebrow">Selected work</p>
                    <h2>Project portfolio</h2>
                </div>
                <p>Practical exercises that turned classroom lessons into working ideas.</p>
            </div>
            <div class="project-grid">
                <?php foreach ($member['projects'] as $index => $project): ?>
                    <article class="project-card">
                        <div class="project-topline">
                            <span>Investment <?= str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                            <span aria-hidden="true">&nearr;</span>
                        </div>
                        <h3><?= esc($project['title']) ?></h3>
                        <p><?= esc($project['description']) ?></p>
                        <span class="project-tools"><?= esc($project['tools']) ?></span>
                    </article>
                <?php endforeach ?>
            </div>
        </div>
    </section>

    <section class="reflection-section">
        <div class="container reflection-grid">
            <div>
                <p class="eyebrow">Group project reflection</p>
                <h2>My role in the portfolio</h2>
            </div>
            <blockquote><?= esc($member['reflection']) ?></blockquote>
        </div>
    </section>

    <section class="contact-section">
        <div class="container contact-grid">
            <div>
                <p class="eyebrow">Contact information</p>
                <h2>Let’s build something useful.</h2>
            </div>
            <address class="contact-list">
                <a href="mailto:<?= esc($member['email']) ?>"><span>Email</span><?= esc($member['email']) ?></a>
                <a href="tel:<?= esc(str_replace(' ', '', $member['phone'])) ?>"><span>Phone</span><?= esc($member['phone']) ?></a>
                <p><span>Location</span><?= esc($member['location']) ?></p>
            </address>
        </div>
    </section>
</main>
