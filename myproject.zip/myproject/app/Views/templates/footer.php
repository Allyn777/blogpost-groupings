<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <a class="brand brand-footer" href="<?= site_url('/') ?>">
                <span class="brand-mark" aria-hidden="true"><span></span><span></span><span></span></span>
                <span>Fund<span>Forward</span></span>
            </a>
            <p>A student portfolio about skills, ideas, and investing in growth.</p>
        </div>
        <div class="footer-note">
            <p class="eyebrow">Built with</p>
            <p>CodeIgniter 4 &middot; No database &middot; Student project</p>
        </div>
    </div>
    <div class="container footer-bottom">
        <p>&copy; <?= date('Y') ?> FundForward Group Portfolio</p>
        <a href="#main-content">Back to top</a>
    </div>
</footer>
</body>
</html>
