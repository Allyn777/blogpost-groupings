<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="<?= site_url('/') ?>" aria-label="FundForward home">
            <span class="brand-mark" aria-hidden="true">
                <span></span><span></span><span></span>
            </span>
            <span>Fund<span>Forward</span></span>
        </a>

        <nav class="main-nav" aria-label="Main navigation">
            <a class="<?= $activePage === 'home' ? 'active' : '' ?>" href="<?= site_url('/') ?>">Home</a>
            <a class="<?= $activePage === 'member-1' ? 'active' : '' ?>" href="<?= site_url('member-1') ?>">Allyn</a>
            <a class="<?= $activePage === 'member-2' ? 'active' : '' ?>" href="<?= site_url('member-2') ?>">Florhen</a>
            <a class="<?= $activePage === 'member-3' ? 'active' : '' ?>" href="<?= site_url('member-3') ?>">Melcorvin</a>
        </nav>
    </div>
</header>
