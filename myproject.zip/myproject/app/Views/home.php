<?= view('templates/header', ['title' => $title]) ?>
<?= view('templates/navbar', ['activePage' => $activePage]) ?>

<main id="main-content">
    <section class="home-hero">
        <div class="container hero-grid">
            <div class="hero-copy">
                <p class="eyebrow"><span></span> Student portfolio collective</p>
                <h1>Investing in skills.<br><em>Building our future.</em></h1>
                <p class="hero-intro">We are three Information Technology students learning to turn curiosity into useful digital experiences. Explore our work, interests, and the roles we played in this group project.</p>
                <div class="hero-actions">
                    <a class="button button-primary" href="#our-team">Meet the team <span aria-hidden="true">&rarr;</span></a>
                    <a class="text-link" href="#our-story">Read our story</a>
                </div>
            </div>

            <div class="growth-card" aria-label="Group learning snapshot">
                <div class="growth-head">
                    <div>
                        <p class="eyebrow">Our shared capital</p>
                        <p class="growth-value">3 perspectives</p>
                    </div>
                    <span class="status-pill">Growing</span>
                </div>
                <div class="chart" aria-hidden="true">
                    <span style="--height: 34%"></span>
                    <span style="--height: 45%"></span>
                    <span style="--height: 42%"></span>
                    <span style="--height: 61%"></span>
                    <span style="--height: 72%"></span>
                    <span style="--height: 88%"></span>
                    <svg viewBox="0 0 420 150" preserveAspectRatio="none">
                        <path d="M0 130 C55 132 70 105 116 108 S185 92 220 84 S285 68 315 48 S375 38 420 12" />
                    </svg>
                </div>
                <div class="growth-stats">
                    <div><strong>03</strong><span>Team members</span></div>
                    <div><strong>06</strong><span>Featured projects</span></div>
                    <div><strong>01</strong><span>Shared goal</span></div>
                </div>
            </div>
        </div>
    </section>

    <section id="our-story" class="story-section">
        <div class="container story-grid">
            <div>
                <p class="eyebrow">Our story</p>
                <h2>More than a balance sheet</h2>
            </div>
            <div class="story-copy">
                <p>Like responsible lending, learning is built on trust, steady progress, and smart investment. FundForward presents our personal journeys through that lens, not as a lending system, but as a record of the knowledge we are building together.</p>
                <div class="principles">
                    <span>01 &nbsp; Learn openly</span>
                    <span>02 &nbsp; Build simply</span>
                    <span>03 &nbsp; Grow together</span>
                </div>
            </div>
        </div>
    </section>

    <section id="our-team" class="team-section">
        <div class="container">
            <div class="section-heading">
                <div>
                    <p class="eyebrow">The people behind the work</p>
                    <h2>Meet our team</h2>
                </div>
                <p>Three students. Different strengths.<br>One shared investment in growth.</p>
            </div>

            <div class="member-grid">
                <?php foreach ($members as $member): ?>
                    <article class="member-card">
                        <div class="member-image-wrap">
                            <span class="member-number"><?= esc($member['number']) ?></span>
                            <img src="<?= base_url($member['image']) ?>" alt="Portrait illustration of <?= esc($member['name']) ?>">
                        </div>
                        <div class="member-card-body">
                            <p class="member-role"><?= esc($member['role']) ?></p>
                            <h3><?= esc($member['name']) ?></h3>
                            <p><?= esc($member['focus']) ?></p>
                            <a href="<?= site_url($member['route']) ?>">View portfolio <span aria-hidden="true">&nearr;</span></a>
                        </div>
                    </article>
                <?php endforeach ?>
            </div>
        </div>
    </section>

    <section class="closing-banner">
        <div class="container closing-grid">
            <p class="eyebrow">Our outlook</p>
            <blockquote>“The best return on investment is the person you become while learning.”</blockquote>
            <span>FundForward Team &middot; 2026</span>
        </div>
    </section>
</main>

<?= view('templates/footer') ?>
