<?php

namespace App\Controllers;

class MemberThree extends BaseController
{
    public function index(): string
    {
        // Edit this array when you are ready to add the student's real details.
        $data = [
            'title'      => 'Melcorvin C. Macaliag | FundForward',
            'activePage' => 'member-3',
            'member'     => [
                'number'       => '03',
                'name'         => 'Melcorvin C. Macaliag',
                'role'         => 'UI/UX Designer',
                'image'        => 'assets/images/mel.jpg',
                'introduction' => 'I am an aspiring software developer who likes understanding how applications work behind the interface. I focus on writing straightforward code, solving problems carefully, and learning one concept at a time.',
                'education'    => [
                    'program' => 'Bachelor of Science in Information Technology',
                    'school'  => 'St Peters College',
                    'year'    => 'Fourth Year Student',
                ],
                'skills'       => ['PHP', 'CodeIgniter 4', 'Problem Solving', 'Git Basics', 'Technical Documentation'],
                'hobbies'      => ['Cycling', 'Strategy games', 'Coding exercises', 'Technology videos'],
                'projects'     => [
                    [
                        'title'       => 'Library Record System',
                        'description' => 'A school exercise for organizing books and borrower records with clear validation rules.',
                        'tools'       => 'PHP, MySQL, Bootstrap',
                    ],
                    [
                        'title'       => 'Weather Information Page',
                        'description' => 'A compact page that retrieves and presents forecast information in an easy-to-scan format.',
                        'tools'       => 'JavaScript, REST API, CSS',
                    ],
                ],
                'email'        => 'melcorvinmacaliag@gmail.com',
                'phone'        => '+63 934 567 8901',
                'location'     => 'Iligan City, Philippines',
                'reflection'   => 'I organized the CodeIgniter routes and controllers and checked that our pages worked consistently. The project helped me understand how shared views reduce repetition and keep a website easier to maintain.',
            ],
        ];

        return view('members/member_three', $data);
    }
}
