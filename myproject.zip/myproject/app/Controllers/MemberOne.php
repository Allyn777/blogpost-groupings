<?php

namespace App\Controllers;

class MemberOne extends BaseController
{
    public function index(): string
    {
        // Edit this array when you are ready to add the student's real details.
        $data = [
            'title'      => 'Allyn Marc C. Dumapias | FundForward',
            'activePage' => 'member-1',
            'member'     => [
                'number'       => '01',
                'name'         => 'Allyn Marc C. Dumapias',
                'role'         => 'It Support',
                'image'        => 'assets/images/allyn.png',
                'introduction' => 'I am an Information Technology student who enjoys turning ideas into websites that feel clear, friendly, and easy to use. I am currently building my confidence in responsive design and modern web development.',
                'education'    => [
                    'program' => 'Bachelor of Science in Information Technology',
                    'school'  => 'St Peters College',
                    'year'    => 'Fourth Year Student',
                ],
                'skills'       => ['HTML & CSS', 'JavaScript', 'Responsive Design', 'Figma', 'CodeIgniter 4'],
                'hobbies'      => ['Street photography', 'Basketball', 'Interface design', 'Personal finance podcasts'],
                'projects'     => [
                    [
                        'title'       => 'Campus Budget Tracker',
                        'description' => 'A responsive dashboard concept that helps students organize weekly allowances and expenses.',
                        'tools'       => 'HTML, CSS, JavaScript',
                    ],
                    [
                        'title'       => 'Local Cafe Website',
                        'description' => 'A mobile-first promotional website with a menu, location details, and accessible navigation.',
                        'tools'       => 'HTML, CSS, Figma',
                    ],
                ],
                'email'        => 'alynmarcdumapias@gmail.com',
                'phone'        => '+63 912 345 6789',
                'location'     => 'Iligan City, Philippines',
                'reflection'   => 'I led the visual implementation of our group portfolio. This project taught me to turn a design direction into reusable components and to test every layout on smaller screens.',
            ],
        ];

        return view('members/member_one', $data);
    }
}
