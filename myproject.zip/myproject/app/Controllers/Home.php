<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        $data = [
            'title'      => 'FundForward | Student Portfolio',
            'activePage' => 'home',
            'members'    => [
                [
                    'name'   => 'Allyn Marc C. Dumapias',
                    'role'   => 'It Support',
                    'focus'  => 'Clear interfaces and accessible experiences',
                    'image'  => 'assets/images/allyn.png',
                    'route'  => 'member-1',
                    'number' => '01',
                ],
                [
                    'name'   => 'Dec Florhen T. Uy',
                    'role'   => 'Content & UI Designer',
                    'focus'  => 'Useful content shaped into thoughtful layouts',
                    'image'  => 'assets/images/dec.jpg',
                    'route'  => 'member-2',
                    'number' => '02',
                ],
                [
                    'name'   => 'Melcorvin C. Macalig',
                    'role'   => 'UI/UX Designer',
                    'focus'  => 'Simple systems and dependable application logic',
                    'image'  => 'assets/images/mel.jpg',
                    'route'  => 'member-3',
                    'number' => '03',
                ],
            ],
        ];

        return view('home', $data);
    }
}
