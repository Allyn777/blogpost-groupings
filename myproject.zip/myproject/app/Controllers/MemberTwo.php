<?php

namespace App\Controllers;

class MemberTwo extends BaseController
{
    public function index(): string
    {
        // Edit this array when you are ready to add the student's real details.
        $data = [
            'title'      => 'Dec Florhen T. Uy | FundForward',
            'activePage' => 'member-2',
            'member'     => [
                'number'       => '02',
                'name'         => 'Dec Florhen T. Uy',
                'role'         => 'Content & UI Designer',
                'image'        => 'assets/images/dec.jpg',
                'introduction' => 'I am a creative computing student interested in visual communication and user-centered design. I enjoy organizing information so people can understand it quickly and feel confident using a website.',
                'education'    => [
                    'program' => 'Bachelor of Science in Information Technology',
                    'school'  => 'St Peters College',
                    'year'    => 'Fourth Year Student',
                ],
                'skills'       => ['UI Design', 'Content Writing', 'Wireframing', 'Canva', 'HTML & CSS'],
                'hobbies'      => ['Digital illustration', 'Reading', 'Journaling', 'Community volunteering'],
                'projects'     => [
                    [
                        'title'       => 'StudyShare Prototype',
                        'description' => 'A collaborative study-resource concept designed around simple navigation and readable content.',
                        'tools'       => 'Figma, Canva, User Research',
                    ],
                    [
                        'title'       => 'Financial Literacy Campaign',
                        'description' => 'A set of student-friendly social posts explaining savings, needs, wants, and responsible borrowing.',
                        'tools'       => 'Canva, Copywriting',
                    ],
                ],
                'email'        => 'decflorhen@gmail.com',
                'phone'        => '+63 923 456 7890',
                'location'     => 'Iligan City, Philippines',
                'reflection'   => 'I developed the content structure and helped define the finance-inspired visual direction. I learned that good design is not only decoration; it guides attention and makes information easier to understand.',
            ],
        ];

        return view('members/member_two', $data);
    }
}
