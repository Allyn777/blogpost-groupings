<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('member-1', 'MemberOne::index');
$routes->get('member-2', 'MemberTwo::index');
$routes->get('member-3', 'MemberThree::index');
